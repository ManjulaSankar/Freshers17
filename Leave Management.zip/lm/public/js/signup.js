$(document).ready(function(){

	var dateFormat = "mm-dd-yy";
	$( "#dob" ).datepicker({ minDate: "-40Y", maxDate: "-21Y+14D"});

	$(document).on("click","#signUp",function(e){
		e.preventDefault();
		var mail = $("#mail").val();
		var name = $("#name").val();
		var dob = $("#dob").val();		
		var mobileNum = $("#mobileNum").val();
		var pwd = $("#pwd").val();
		var repwd=$("#cpwd").val();

		if(mail == "" || name ==  "" || dob == "" || mobileNum == "" || pwd  == "" || repwd == ""){
			$.bootstrapGrowl('Please fill all the fields',{
			    type: 'danger',
			    delay: 2000,
			});
		}
		else{
			var nameTest = checkInputName(name,"^[a-z A-Z]{3,25}$");
			var mailTest= checkInputEmail(mail,"^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+.[A-Za-z]{2,4}$");
			var mobileNumTest= checkInputMobile(mobileNum,"^[0-9-()+]{10}$");
			var pwdTest = checkInputPassword(pwd,repwd);
			if(nameTest && mailTest && mobileNumTest && pwdTest){
				dpd.users.post({"username": name, "password":pwd,"name":name,"dob":dob,"mail":mail,"phone":mobileNum,"roleassigned":false}, function(user, err) {
					if(err) return $.bootstrapGrowl("The User name is already used,Please try another",{
										type:"success",
										delay:4000
									});

					window.location.href = "signin.html"
				});
			}
		}
	});	

	function checkInputName(element,regEx){
		var textInput=element;
		var namereg=new RegExp(regEx);
		if(textInput.length!=0){
			if (namereg.test(textInput)) {
				return true;
			}
			else{
				$.bootstrapGrowl("Name must have 3 characters",{
					type:"danger",
					delay:4000
				});
				$("#name").val("");
				return false;
			}
		}
	}
	
	function checkInputEmail(element,regEx){
		var textInput=element;
		var namereg=new RegExp(regEx);
		if(textInput.length!=0){
			if (namereg.test(textInput)) {
				// successFeedback(element, successfeedbackDetail);
				// console.log(element,"Valid Input");
				return true;
			}
			else{
				$.bootstrapGrowl("Give the valid email",{
					type:"danger",
					delay:4000
				});
				$("#mail").val("");
				return false;
			}
		}
	}
	
	function checkInputMobile(element,regEx){
		var textInput=element;
		var namereg=new RegExp(regEx);
		if(textInput.length!=0){
			if (namereg.test(textInput)) {
				return true;
			}
			else{
				$.bootstrapGrowl("Give the valid 10 digit Mobile Number",{
					type:"danger",
					delay:4000
				});
				$("#mobileNum").val("");
				return false;
			}
		}
	}
	
	function checkInputPassword(pwd,repwd){
		if(pwd == repwd)
			return true;
		else{
			$.bootstrapGrowl("Password Mismatch",{
				type:"danger",
				delay:4000
			});
			$("#pwd").val("");
			$("#cpwd").val("");
			return false;
		}
	}

	function clearData(){
		$("#name").val("");
		$("#dob").val("");
		$("#mail").val("");
		$("#mobileNum").val("");
		$("#pwd").val("");
		$("#cpwd").val("");
	}

});
