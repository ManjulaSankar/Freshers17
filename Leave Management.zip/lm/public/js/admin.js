$(document).ready(function(){

	dpd.admin.me(function(user) {
	    if (user) {
	        $('h5').append(user.username);
	    } else {
	        location.href = "index.html";
	    }
    });

    $(document).on("click","#logout", function() {
      	dpd.admin.logout(function(res, err) {
        	location.href = "index.html";
      	});
    });

	showRecords();	

	$(document).on("click","#userRecordBtn",function(){		
		showRecords();

	});

	function showRecords(){
		dpd.users.get(function (result, err) {
			if(err) return console.log(err);
			else if(result.length != 0){
				for(var i=0;i<result.length; i++){
					var name = result[i].name;
					var dob = result[i].dob;
					var email = result[i].mail;
					var phone = result[i].phone;
					var role =result[i].role;
					if(role == undefined || role == ""){
						$(".userRecords").find("tbody").append('<tr><td>'+ (i+1) +'<td class="name">' + name +'</td><td>'+ dob +'</td><td>' + email +'</td><td>'+ phone +'</td><td><a href="#" id="assignRoletoNewUser">Assign role</a></td></tr>');
					}
					else{

						$(".userRecords").find("tbody").append('<tr><td>'+ (i+1) +'<td class="name">' + name +'</td><td>'+ dob +'</td><td>' + email +'</td><td>'+ phone +'</td><td>' +result[i].role + '</td></tr>');
					}					
					var record = $(".userRecords").html();
					$(".adminCard").find(".card-block").html(record);
				}
			}
			else{
				$(".adminCard").find(".card-block").html('<h4 class="text-center align-middle">No user Record found</h4>');
			}
							  	 
		});
	}

	$(document).on("click","#assignRoletoNewUser",function(){
		var name = $(this).closest("tr").children(".name").html();		
		$(".userCreationForm").find("input").attr("value",name);

		var form = $(".userCreationForm").html();
		$(".adminCard").find(".card-block").html(form);
	});
	
	// Assign a role for the new user (manager , employee) by the admin
	$(document).on("click","#btnAssignRole",function(){				
		var name = $("#name").val();		
		var role = $("#roleSelect option:selected").val();
		var mng = $("#mngSelect option:selected").val();

		var query = {"name":name};
		dpd.users.get(query, function (result) {
			if(result.length != 0){
				if(role == "employee" && mng != undefined){
					dpd.users.put(result[0].id,{"role":role,"manager":mng,"roleassigned":true}, function(result, err) {
		  				if(err) return console.log(err);
		  					window.location.reload();
		  					// $.bootstrapGrowl("New employee is assigned",{type: 'success',align: 'right',delay: 4000});
					});		
				}
				else if(role  == "manager"){
					dpd.users.put(result[0].id, {"role":role,"manager":"","roleassigned":true}, function(result, err) {
						if(err) return console.log(err);
							window.location.reload();
						// $.bootstrapGrowl("New manager is assigned",{type: 'success',align: 'right',delay: 4000});
					});				
				}
				else if(role == ""){
					$.bootstrapGrowl("Please select a role",{type: 'danger',delay: 4000});
				}
				else{
					$.bootstrapGrowl("You can't submit without assigning manager",{type: 'danger',delay: 4000});
				}
			
			}
			else{
				$.bootstrapGrowl("Invalid user name",{type: 'danger',delay: 4000});
			}
							
		});
	});

	$(document).on("change","#roleSelect",function(){
		var role = $(this).val();
		if(role == "employee"){
			var query = {"role":"manager","roleassigned":true};
			dpd.users.get(query, function (result) {
			  	if(result.length  != 0){
			  		$(".manager").find("select").html("");
				  	for(var i=0; i<result.length; i++){
				  		$(".manager").find("select").append("<option>" + result[i].name + "</option>"); 
				  	}
				  	$(".manager").removeAttr("hidden");
			  	}
			  		  	
			});
		}
		else{
			$(".manager").attr("hidden","hidden");
		}		
	});	

	$(document).on("click","#leaveConfigAdmin",function(){		

		var query = {"role":"employee","roleassigned":true};
		dpd.users.get(query, function (result) {
			console.log(result);
			for(var i=0;i<result.length;i++){
				$(".leaveConfig").find("tbody").append('<tr><td>'+ result[i].name +'</td><td>' + 3 +'</td><td>'+ 3 +'</td><td>'+ 6 +'</td></tr>');
			}
			var leaveData = $(".leaveConfig").html();
		$(".adminCard").find(".card-block").html(leaveData);
		});
	});

});