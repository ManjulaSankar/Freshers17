$(document).ready(function(){

	// For logout function
	dpd.users.me(function(user) {
	    if (user) {
	    	$('h5').append(user.username);
	        $('h6').append(user.role);
	    } else {
	        location.href = "index.html";
	    }
    });

    $('#logout').click(function() {
      	dpd.users.logout(function(res, err) {
        	location.href = "index.html";
      	});
    });
	applyLeavesRecord();
	// Manager can see the applied leave forms
	$(document).on("click","#applyLeavesMng",function(){
		applyLeavesRecord();
	});

	function applyLeavesRecord(){
		var query = {"status":false};
		dpd.leaveform.get(query, function (result) {
			var status;
			$(".leaveList").find("tbody").html("");
			for(var i=0; i<result.length; i++){
				var leaveData = '<td>' + (i+1) + '</td>\
								<td>' + result[i].name + '</td>\
								<td>' + result[i].emailId + '</td>\
								<td>' + result[i].startDate + '</td>\
								<td>' + result[i].endDate + '</td>\
								<td>' + result[i].totalDays + '</td>\
								<td>' + result[i].type + '</td>\
				                <td><button type="button" class="btn btn-secondary mngApproved">Waiting for Approval</button></td>';

				$(".leaveList").find("tbody").append("<tr>" + leaveData +"</tr>");
			}
		});
	}

	$(document).on("click",".mngApproved",function(){
		$(this).html("Approved");
		var id = $(this).parent().siblings(".empId").html();
		dpd.leaveform.get({"empId" : id}, function(result, err) {
			  var emplId = result[0].id;
			  dpd.leaveform.put(emplId,{"status": true},function(result,err){
			  	if (err) return console.log(err);
			  	console.log(result, result.id);
			  });
			  if(err) return console.log(err);
			  console.log(result, result.id);
		});
	});

	// Manager will see the applied leaves
	$(document).on("click","#btnApprovedMng",function(){
		var query = {"status":true};
		dpd.leaveform.get(query, function (result) {
			var status;
			$(".leaveList").find("tbody").html("");
			for(var i=0; i<result.length; i++){
				var leaveData = '<td>' + (i+1) + '</td>\
								<td>' + result[i].name + '</td>\
								<td>' + result[i].emailId + '</td>\
								<td>' + result[i].startDate + '</td>\
								<td>' + result[i].endDate + '</td>\
								<td>' + result[i].totalDays + '</td>\
								<td>' + result[i].type + '</td>\
				                <td><button type="button" class="btn btn-secondary mngApproved"> Approved </button></td>';

				$(".leaveList").find("tbody").html("<tr>" + leaveData +"</tr>");
			}
		});
	});	
	
	
});

