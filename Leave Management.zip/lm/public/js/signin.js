$(document).ready(function(){
	
	$(document).on("click","#login",function(e){
		e.preventDefault();
		var uname = $("#uname").val();
		var pwd= $("#pwd").val();

		dpd.admin.login({username: uname,password: pwd}, function(result, error) {
			if(result) window.location.href = "admin.html";
		 	else{		 		
		 		dpd.users.login({username: uname,password: pwd}, function(result, error) {
  					if(result){
  						var id = result.uid;
  						dpd.users.get(id, function (result) {
							if(result.roleassigned == true){
								if(result.role == "employee"){
									window.location.href = "emp.html";
								}
								if(result.role == "manager"){
									window.location.href = "mng.html";
								}
							}
							else if(result.roleassigned == false){
								$.bootstrapGrowl("Wait until the role is assigned for you",{
									type: 'info',
									delay: 4000
								});	
							}				
							
						});					
  				  	}
  				  	else{
  				  		$.bootstrapGrowl('Invalid login.Please try again',{
					        type: 'danger',
					        delay: 2000,
					    });
  				  	} 				  	
  				 
  				});		 							
			}				
			
		});	
	});

	function clearData(){
		$("#uname").val("");
		$("#pwd").val("");
	}

});