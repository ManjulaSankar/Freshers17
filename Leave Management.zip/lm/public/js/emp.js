$(document).ready(function(){
	
	dpd.users.me(function(user) {
	    if (user) {
	        $('h5').append(user.username);
	        $('h6').append(user.role);
	    } else {
	        location.href = "index.html";
	    }
    });
    
    $('#logout').click(function() {
	    dpd.users.logout(function(res, err) {
	        location.href = "index.html";
	    });
    });

    $( ".from",".to").datepicker({
	  	dateFormat: "mm-dd-yy"
	});

    $("#fromDate").datepicker();
    $("#toDate").datepicker();
    nameMail();

	var dateFormat = "mm/dd/yy",
    from = $( "#from" ).datepicker({
			        defaultDate: "+1w",
			        changeMonth: true,
			        numberOfMonths: 1,
			        minDate:"+0D",
			        maxDate: "+3M"
        	}).on( "change", function() {
          		to.datepicker("option", "minDate", getDate( this ),calcDiff() );
        	}),

    to = $( "#to" ).datepicker({
		        defaultDate: "+1w",
		        changeMonth: true,
		        numberOfMonths: 1,
		        minDate: "+1D", 
		        maxDate: "+3M"
		}).on( "change", function() {
	        from.datepicker("option", "maxDate", getDate( this ),calcDiff() );
	      });
 
    function getDate( element ) {
      	var date;
      	try {
        	date = $.datepicker.parseDate( dateFormat, element.value );
      	} catch( error ) {
        	date = null;
      	}
 	    return date;
 	}
 	
    function calcDiff() {
        var d1 = $('#from').datepicker('getDate');
        var d2 = $('#to').datepicker('getDate');
        var diff = 0;
        if (d1 && d2) {
              diff = Math.floor((d2.getTime() - d1.getTime()) / 86400000); // ms per day
              if(diff == 0){
              	diff = 1;
              }
              else{
              	diff +=1;
              }
        }
        $('#noDays').val(diff);
    }
	
    function nameMail(){
    	dpd.users.me(function(user) {
		    if (user)
		        $(".empName").find("input").attr("value",user.name);
		    	$(".empMail").find("input").attr("value",user.mail);
    	});
    }

	// Apply for a leave to the manager
	$("#leaveSubmitBtn").on("click",function(){	
		
		var type = $("#leaveTypeSelect option:selected").val();
		var fromDate = $("#from").val();
		var toDate = $("#to").val();
		var mailId = $("#mailId").val();
		var name = $("#name").val();
		var days = $("#noDays").val();
		if(name == "" || mailId == "" || type == "" || fromDate =="" || toDate == "" || days == ""){
			$.bootstrapGrowl('Please fill all the fields',{
			    type: 'danger',
			    delay: 2000,
			});
		}
		else{
			dpd.leaveform.post({"name":name,"emailId":mailId,"type":type,"startDate":fromDate,"endDate":toDate,"totalDays":days,"status":false}, function(result, err) {
				if(result){					
	  				$.bootstrapGrowl("Leave is Submitted to manager",{
	  					type: 'success',
	  					delay: 4000
	  				});
	  				$("#from").val("");
	  				$("#to").val("");
	  				$("#leaveTypeSelect").val("");
	  				$("#noDays").val("");
				} 
	  				
	  		});
		}		
				
	});
		
	$("#leaveSendBack").on("click",function(){
		var query = {"status":false};
		dpd.leaveform.get(query, function (result) {
		  	var id = result[result.length-1].id;
		  	dpd.leaveform.del(id, function (err) {
				 if(err) console.log(err);
			});
		});	
		
	});


	$("#leaveBalance").on("click",function(){
		var leave = $(".available").html();
		$(".empLeave").html(leave);
	});

	$("#leaveStatus").on("click",function(){
		var leave = $(".leaveReport").html();
		$(".empLeave").html(leave);
	});

	$(document).on("click","#leaveCancel",function(){
		var cancelForm = $(".cancelLeaveForm").html();
		$(".empLeave").html(cancelForm);
		// $(".cancelLeaveForm").removeAttr("hidden");
	});

	$(document).on("click","#leaveCancelBtn",function(){
		var leaveType = $("#selectLeaveType option:selected").val();	
		var fromDate = $("#fromDate").val();
		var toDate = $("#toDate").val();

		var query = {"type":leaveType,"startDate":fromDate,"endDate":toDate,"status":false};
			dpd.leaveform.get(query, function (result) {
				if(result)
			  console.log(result);
			});
	});
});